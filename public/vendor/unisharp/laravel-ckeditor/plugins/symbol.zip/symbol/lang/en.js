﻿CKEDITOR.plugins.setLang("symbol","en",{options:"Symbol Options",title:"Select Symbol",toolbar:"Insert Symbol"});
